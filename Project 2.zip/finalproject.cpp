//finalproject.cpp
//Jennifer Moreno
//April 14, 2016

#include<iostream>
#include<fstream>
#include<ctime>
#include<string>
#include<cstdlib>
using namespace std;

const int SIZE = 3;

//define struct called Player
struct Player
{
	//data members
	int score;
	string name;
	int choice1, choice2, choice3;

	//constructor
	Player()
	{
		score = 1;
		name = "John";
		choice1 = 1;
		choice2 = 1;
		choice3 = 1;
	}
};

//function prototypes
//return type: void
//parameters: none
//purpose: this function displays the rules for the game
void DisplayRules();

//return type: int
//parameters: 1 by reference: 1 int (menuChoice)
//purpose: This function displays the main menu of the game and returns the menuChoice
void DisplayMainMenu(int &menuChoice);

//return type: int
//parameters: 1 by reference: 1 int (c1)
//purpose: This function displays the first game menu and returns the users choice
int DisplayMenu1(int &c1);

//return type: int
//parameters: 1 by reference: 1 int (c2)
//purpose: This function displays the second game menu and returns the users choice
int DisplayMenu2(int &c2);

//return type: int
//parameters: 1 by reference: 1 int (c3)
//purpose: This function displays the third game menu and returns the users choice
int DisplayMenu3(int &c3);

//return type: bool
//parameters: three value parameters: int, int, int (n, min, max))
//purpose: This function returns true if the value n is between min and max, //otherwise returns false
bool IsValidInput(int n, int min, int max);

//return type: int
//parameters: 1 int (random)
//purpose: This function generates random numbers
int RandomNumGenerator(int random);

//return type: void
//parameters: 1 string array (name), 1 int array (scores)
//purpose: This function reads in the highscores from a file called 'highscore.txt'
void ReadInScores(string name[], int scores[]);

//return type: void
//parameters: 1 string (uName), 1 int (uScore)
//purpose: This function replaces the highscore if the user beats it
void ReplaceScores(string names[], int scores[], string uName, int uScore);

int main()
{
	//Generate Random Numbers
	srand(time(NULL));

	//Display and Initialize Variables
	int menuChoice = 0;
	int choice1 = 0, choice2 = 0, choice3 = 0;
	int myRandom = 0, userScore = 0;
	string name[SIZE];
	int scores[SIZE];
	Player player1;

	do
	{
		userScore = 0;

		//Call function to display main menu
		DisplayMainMenu(menuChoice);

		//call function to validate that menuChoice is between 1 and 3
		if (!IsValidInput(menuChoice, 1, 3))
		{
			cout << "Invalid! Choice must be between 1-3 for the main menu!\n\n";
		}

		switch (menuChoice)
		{
		case 1:
			//Call a function to display rules for the game
			DisplayRules();

			break;

		case 2:
			do
			{
				//Call function to display game menu 1
				DisplayMenu1(choice1);

				//call function to validate that choice1 is between 1 and 4
				if (!IsValidInput(choice1, 1, 4))
				{
					cout << "\nInvalid! Choice must be between 1-4!\n\n";
				}

				if (IsValidInput(choice1, 1, 4))
				{
					if (choice1 == 1)
						userScore += RandomNumGenerator(10);
					else if (choice1 == 2)
						userScore += RandomNumGenerator(10);
					else if (choice1 == 3)
						userScore += RandomNumGenerator(10);
					else
						userScore += RandomNumGenerator(10);
				}

				//Display the user's score
				cout << "Your Current Score is: " << userScore;
				cout << endl;
				cout << endl;
				cout << endl;

			} while (!IsValidInput(choice1, 1, 4));


			do
			{
				//Call function to display game menu 2
				DisplayMenu2(choice2);

				//call function to validate that choice2 is between 1 and 4
				if (!IsValidInput(choice2, 1, 4))
				{
					cout << "\nInvalid! Choice must be between 1-4!\n\n";
				}

				if (IsValidInput(choice2, 1, 4))
				{
					if (choice2 == 1)
						userScore += RandomNumGenerator(10);
					else if (choice2 == 2)
						userScore += RandomNumGenerator(10);
					else if (choice2 == 3)
						userScore += RandomNumGenerator(10);
					else
						userScore += RandomNumGenerator(10);
				}

				//Display the user's score
				cout << "Your Current Score is: " << userScore;
				cout << endl;
				cout << endl;
				cout << endl;

			} while (!IsValidInput(choice2, 1, 4));


			do
			{
				//Call function to display game menu 3
				DisplayMenu3(choice3);

				//call function to validate that choice3 is between 1 and 4
				if (!IsValidInput(choice3, 1, 4))
				{
					cout << "\nInvalid! Choice must be between 1-4!\n\n";
				}

				if (IsValidInput(choice3, 1, 4))
				{
					if (choice3 == 1)
						userScore += RandomNumGenerator(10);
					else if (choice3 == 2)
						userScore += RandomNumGenerator(10);
					else if (choice3 == 3)
						userScore += RandomNumGenerator(10);
					else
						userScore += RandomNumGenerator(10);
				}

				//Display the user's score
				cout << "Your Current Score is: " << userScore;
				cout << endl;
				cout << endl;
				cout << endl;

			} while (!IsValidInput(choice3, 1, 4));

			//Prompt for player name
			cout << "Enter your name: ";
			cin >> player1.name;
			cout << endl;

			//Call function to read in scores from highscores.txt
			ReadInScores(name, scores);

			//Set the userScore to be player1.score
			player1.score = userScore;

			//Call function to replace scores in highscores.txt if the user beats one of the highscores
			ReplaceScores(name, scores, player1.name, player1.score);

			break;

		case 3:
			//Display Goodbye message
			cout << "See you in the apocalypse! The undead will be waiting... ;-)\n\n";
		}


	} while (menuChoice != 3);

	return 0;
}




//function definitions
//purpose: this function displays the rules for the game
void DisplayRules()
{
	//Display Rules and storyline

	cout << "   The world as you know it has fallen apart. Food, water, and medicine are\nscarce. There are no hospitals to treat you when you are wounded.";
	cout << " There is no\nmore police or army to keep you safe anymore. In fact, nowhere is safe anymore.\n";
	cout << "And one decision can mean the difference between life and death.";
	cout << " More\nimportantly, trust is hard to come by since people can be just as dangerous as\nthe walking dead.\n\n";

	cout << "This is the zombie apocalypse.\n\n\n";


	cout << "(Rules: You will have three choices to pick from each menu displayed. Use eitherof the numbers 1, 2, or 3 to make your decision.";
	cout << " Each choice will have a score,\nwhich you can see after making each choice. The final score will also be\ndisplayed at the end of the game.";
	cout << " It will be written to a file called\n'highscore.txt' if you happen to beat the high score.)\n\n\n";
}

//purpose: This function displays the main menu of the game and returns the menuChoice
void DisplayMainMenu(int &menuChoice)
{
	//Display main menu
	cout << "*******************\n";
	cout << "*  1) See Rules   *\n";
	cout << "*  2) Play Game   *\n";
	cout << "*  3) Quit        *\n";
	cout << "*******************\n\n";

	//Prompt for Choice
	cout << "Enter your choice: ";
	cin >> menuChoice;
	cout << endl;
}

//purpose: This function displays the first game menu and returns the users choice
int DisplayMenu1(int &c1)
{
	//Display Menu 1
	cout << "   You are sleeping in your apartment in New York City on the 18th floor. You\nsuddenly wake up from an explosion only 1 block away from you.";
	cout << " You can see the\nhavoc from the window in your bedroom. People look as if they are running away\nfrom something or someone, not so much";
	cout << " the blazing fire and flying debris from\nthe top floor. The whole city appears to be in absolute chaos.";
	cout << " You quickly reactand gather your essentials in a bag and get out of your apartment building.\nYou manage to safely reach your car and start the ignition.\n\n";

	cout << "Where do you go?\n";
	cout << "1) Go on your way to your best friend on the other side of the city, hoping to\n   rendevouz safely and successfully.\n";
	cout << "2) Start traveling to the countryside, somewhere far away from the city. Some\n   place you will have no idea what's in store for you.\n";
	cout << "3) Find the nearest emergency shelter and consider staying there until things\n   have calmed down. Or at least until you find out exactly what's going on...\n";
	cout << "4) Make your way to the nearest dock, steal a yacht and wait it out on the\n   rough, open waters.\n\n";

	//Prompt for c1
	cout << "Enter your choice: ";
	cin >> c1;
	cout << endl;

	return c1;
}

//purpose: This function displays the second game menu and returns the users choice
int DisplayMenu2(int &c2)
{
	//Display Menu 2
	cout << "   After about half an hour of driving, your car starts to break down and you\nbegin to panic. You immediately look at the ignition and try to turn";
	cout << " the key\nover and over again, praying that it will work. You realize moments later that\nit's no use and that you'll need to go by foot. As soon as you look up, ";
	cout << "you\nknow you're in trouble. There are 3 people slowly stalking towards you, but theydon't look like people... at least not anymore. All of their eyes appear to be\nlifeless,";
	cout << " with their skin obviously rotting. You thought they only existed in\nmovies or tv shows, but now they're right in front of you. Zombies...\n\n";

	cout << "How do you react?\n";
	cout << "1) You grab your bag of supplies and run out of the car, in the opposite\n   direction of the infected and of your chosen destination. After a few minutes   of running as fast as you ever had";
	cout << " in your life, you begin to grow weak and\n   tired. At least you managed to get away from those 'people'.\n";
	cout << "2) You look around in your car for anything to use as a weapon, you soon find a    crowbar that you kept in your car in case of emergencies, ";
	cout << "seeing that this is   as good of an emergency as any. You hit the closest one in the chest and find   out that it didn't do any good. You instead aim for the head and ";
	cout << "kill the\n   thing... much to your surprise. Because of this newfound knowledge, the last    two go down easily. After handling that near death experience, you retrieve\n   your bag of supplies";
	cout << " from your car and start walking to your destination.\n";
	cout << "3) You stay in your car, thinking its safer in here than out there. You\n   horrifyingly watch as the zombies surround your car only moments later. They    snarl as they try to grab you";
	cout << " from the outside, but of course it's no use.\n   You scream for help and pray for a miracle to get you out of this mess.\n   15 minutes later you see one of the zombies drop to the ground, ";
	cout << "clearly\n   dead(again), but for real this time. The others also fall one by one and you\n   immediately get out of the car and thank your saviors. One woman with\n   pigtails and one man with";
	cout << " a classic mustache, both of them military-like.\n   You grab your bag and part ways with them, heading to your chosen\n   destination. All the while hoping not to run into anymore of the infected.\n";
	cout << "4) You look down again and keep trying to turn the keys in the ignition. After\n   a few more tries your car comes back to life and you step on the gas. While\n   in the process, running";
	cout << " over all of the zombies in your way. Much to your\n   dismay, soon after your car breaks down again, due to all of the zombies'\n   guts getting stuck inside the engine. You then take your bag of supplies";
	cout << " and\n   get out of your car. You quickly look around only to see that there are no\n   zombies near you, so you begin walking to your destination.\n\n";


	//Prompt for c2
	cout << "Enter your choice: ";
	cin >> c2;
	cout << endl;

	return c2;
}

//purpose: This function displays the third game menu and returns the users choice
int DisplayMenu3(int &c3)
{
	//Display Menu 3
	cout << "   As you're walking (more like jogging) past Madison Square Garden, you hear\nscreams coming from inside. For a split-second you falter in your steps and\nrealize you need to get ";
	cout << "out of the this area and fast, not at all curious of\nwhat could be happening in the stadium. As soon as you turn away, you hear the\ndoors bang open. On instinct, you turn back and see hordes of people";
	cout << " run out\nfrantically and you do the same. A few seconds later, you turn back again and\nsee what everyone else was running from. Over a thousand rotters stumbling out\nof the stadium. Police try to shoot at the zombies,";
	cout << " but most of them continue\nstalking toward anybody that would suffice as their meal. You decide that if\nthis is the end, you will not go down without a fight. You run back toward the\nchaos and grab a gun from";
	cout << " a dead officer on the floor, being eaten by one of theinfected. With your adrenaline pulsing, you shoot and kill that zombie and what seems like hundreds more after that. You stop and realize that they are all dead,";
	cout << "all thanks to you and the few police officers still around. The army finally\ncomes by and the medics begin to treat people that are wounded, the rest of\nthe soldiers are assigned to either seal off and guard the area";
	cout << " or kill any\ninfected stragglers. A soldier walks toward you asking for your take on what\nhappened. You oblige and tell him everything you know and the soldier thanks you,asks you to stay for a while longer and walks";
	cout << " away, wanting to report any and\nall information as soon as possible. After reporting to his commanding officer,\nthe same soldier comes back and tells you that his CO believes you can be a\nvaluable asset";
	cout << " to this war of ours.\n\n";

	cout << "What will you decide?\n";
	cout << "1) You are more than happy to help and agree to join the fight against the\n   infected. Over the course of a few days, you are fully trained and know how\n   to handle yourself in any kind of fight. Whether it be";
	cout << " against the living or\n   the dead. You are then assigned to aid soldiers in Los Angeles, due to the\n   lack of aid and control there. You take the helicopter the next morning and\n   pray that this will all be over soon.\n";
	cout << "2) You create your own battle against the dead, deciding to stay in New York\n   City and helping those who need it. You continually do your part by assisting   people surrounded by zombies, ";
	cout << "stopping dangerous people from harming others,    and finding supplies for those in need. Eventually, you build a strong\n   reputation for yourself and become the leader of a powerful group that\n   protect";
	cout << " and help people all over New York.\n";
	cout << "3) You choose to continue to head to the countryside, hoping things are better\n   over there than in this city. Weeks later, you successfully arrive in Senoia,   Georgia and meet a large group, including your saviors. Eventually you all\n";
	cout << "   practically become a family and overcome numerous obstacles together,\n   sometimes involving the loss of your closest friends in the group. Despite\n   the world continually becoming worse, you manage to make a good life for\n";
	cout << "   yourself and the people around you.\n";
	cout << "4) You decide to gather all of your friends and loved ones, the ones that are\n   alive at least, onto the yacht you were planning to steal, stocked with\n   supplies to last all of you a while before you have";
	cout << " to go back to the\n   mainland. While sailing on the open waters around the East Coast, you've came   across harsh weather and other people sailing on boats and yachts. Of course,   some were friendly and some were definitely not.";
	cout << " Sadly, because of all the\n   fighting between your group and those unfriendly people, you've lost two of\n   your closest friends and mourn for them. Then as leader of your group, you\n   decide a few weeks later to start ";
	cout << "setting sail to Hawaii for a change of\n   scenery, seeing that you have enough supplies for the trip. Two weeks later,\n   you and your whole group are excited when you all see the first sign of land\n   of Hawaii. However, you can only";
	cout << " hope that life will be better there, not\n   once did you or anyone in your group hear any reports on what is happening\n   there.\n\n";

	//Prompt for c3
	cout << "Enter your choice: ";
	cin >> c3;
	cout << endl;

	return c3;
}

//purpose: This function returns true if the value n is between min and max, //otherwise returns false
bool IsValidInput(int n, int min, int max)
{
	if (n >= min && n <= max)
	{
		return true;
	}
	else
		return false;
}

//purpose: This function generates random numbers
int RandomNumGenerator(int random)
{
	return rand() % random + 1;
}

//purpose: This function reads in the highscores from a file called 'highscore.txt'
void ReadInScores(string name[], int scores[])
{
	//Declare file pointer for input
	ifstream infile;

	//Open file "highscore.txt"
	infile.open("highscore.txt", ios::in);
	//If no file
	if (!infile)
	{
		cout << "File not found!\n\n";
	}
	//Read in "highscore.txt"
	for (int i = 0; i < SIZE; i++)
	{
		infile >> name[i] >> scores[i];
	}

	cout << "*************** HIGHSCORES ***************\n\n";
	//Display name and scores
	for (int i = 0; i < SIZE; i++)
	{
		cout << "\t\t" << i + 1 << ". " << name[i] << " " << scores[i] << "\n";
	}
	cout << "******************************************\n\n\n";

	//Close "highscore.txt"
	infile.close();
}

//purpose: This function replaces the highscore if the user beats it
void ReplaceScores(string names[], int scores[], string uName, int uScore)
{
	//Declare file pointer for output
	ofstream outfile;

	//Open file "highscore.txt"
	outfile.open("highscore.txt", ios::out);

	if (uScore > scores[0])
	{
		//Display congrats
		cout << "Congrats! You beat the 1st highscore!\n\n";

		//Replace 1st Score
		scores[2] = scores[1];
		names[2] = names[1];
		names[1] = names[0];
		scores[1] = scores[0];
		scores[0] = uScore;
		names[0] = uName;

		//Write to highscores.txt
		outfile << names[0] << " " << scores[0] << "\n";
		outfile << names[1] << " " << scores[1] << "\n";
		outfile << names[2] << " " << scores[2] << "\n";

		//Display new highscores
		cout << "************* NEW HIGHSCORES *************\n\n";
		cout << "\t\t1. " << names[0] << " " << scores[0] << "\n";
		cout << "\t\t2. " << names[1] << " " << scores[1] << "\n";
		cout << "\t\t3. " << names[2] << " " << scores[2] << "\n";
		cout << "******************************************\n\n\n";
	}

	else if (uScore > scores[1])
	{
		//Display congrats
		cout << "Congrats! You beat the 2nd highscore!\n\n";

		//Replace 2nd Score
		scores[2] = scores[1];
		names[2] = names[1];
		names[1] = uName;
		scores[1] = uScore;
		scores[0] = scores[0];
		names[0] = names[0];

		//Write to highscores.txt
		outfile << names[0] << " " << scores[0] << "\n";
		outfile << names[1] << " " << scores[1] << "\n";
		outfile << names[2] << " " << scores[2] << "\n";

		//Display new highscores
		cout << "************* NEW HIGHSCORES *************\n\n";
		cout << "\t\t1. " << names[0] << " " << scores[0] << "\n";
		cout << "\t\t2. " << names[1] << " " << scores[1] << "\n";
		cout << "\t\t3. " << names[2] << " " << scores[2] << "\n";
		cout << "******************************************\n\n\n";

	}

	else if (uScore > scores[2])
	{
		//Display congrats
		cout << "Congrats! You beat the 3rd highscore!\n\n";

		//Replace 3rd Score
		scores[2] = uScore;
		names[2] = uName;
		names[1] = names[1];
		scores[1] = scores[1];
		scores[0] = scores[0];
		names[0] = names[0];

		//Write to highscores.txt
		outfile << names[0] << " " << scores[0] << "\n";
		outfile << names[1] << " " << scores[1] << "\n";
		outfile << names[2] << " " << scores[2] << "\n";

		//Display new highscores
		cout << "************* NEW HIGHSCORES *************\n\n";
		cout << "\t\t1. " << names[0] << " " << scores[0] << "\n";
		cout << "\t\t2. " << names[1] << " " << scores[1] << "\n";
		cout << "\t\t3. " << names[2] << " " << scores[2] << "\n";
		cout << "******************************************\n\n\n";
	}

	else
		//Display Game Over
		cout << "Game Over! :-( \n\n";

	//Close "highscore.txt"
	outfile.close();
}